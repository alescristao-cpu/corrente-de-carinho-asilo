const fs = require('fs');
let file = 'index.html';
let content = fs.readFileSync(file, 'utf-8');

// Replace Mercado Pago recurring link
content = content.replace(/https:\/\/www\.mercadopago\.com\.br\/subscriptions\/checkout\?preapproval_plan_id=2c938084926a87e501926d0d054000b7/g, 'https://obrasocialcristorei.org.br/doe/');

// Update other donation links that were just pointing to the homepage
// but leave the pure "visit website" links as the homepage
const domLinks = [
  '<a href="http://www.obrasocialcristorei.org.br" target="_blank" rel="noopener noreferrer" class="donate-btn-header">',
  '<a href="http://www.obrasocialcristorei.org.br" target="_blank" class="btn-primary">',
  '<a href="http://www.obrasocialcristorei.org.br" target="_blank" class="btn-donate-inline">',
  '<a href="http://www.obrasocialcristorei.org.br" target="_blank" rel="noopener noreferrer" class="btn-donate-modal">\n              ❤️ FAZER DOAÇÃO NO SITE OFICIAL'
];

content = content.replace('<a href="http://www.obrasocialcristorei.org.br" target="_blank" rel="noopener noreferrer" class="donate-btn-header">', '<a href="https://obrasocialcristorei.org.br/doe/" target="_blank" rel="noopener noreferrer" class="donate-btn-header">');
content = content.replace('<a href="http://www.obrasocialcristorei.org.br" target="_blank" class="btn-primary">', '<a href="https://obrasocialcristorei.org.br/doe/" target="_blank" class="btn-primary">');
content = content.replace('<a href="http://www.obrasocialcristorei.org.br" target="_blank" class="btn-donate-inline">', '<a href="https://obrasocialcristorei.org.br/doe/" target="_blank" class="btn-donate-inline">');
content = content.replace(/<a href="http:\/\/www\.obrasocialcristorei\.org\.br" target="_blank" rel="noopener noreferrer" class="btn-donate-modal">\s*❤️ FAZER DOAÇÃO NO SITE OFICIAL/g, '<a href="https://obrasocialcristorei.org.br/doe/" target="_blank" rel="noopener noreferrer" class="btn-donate-modal">\n              ❤️ FAZER DOAÇÃO NO SITE OFICIAL');

// Footer update
content = content.replace('contribuição oficial em <a href="http://www.obrasocialcristorei.org.br" target="_blank">www.obrasocialcristorei.org.br</a>', 'contribuição oficial em <a href="https://obrasocialcristorei.org.br/doe/" target="_blank">obrasocialcristorei.org.br/doe/</a>');

fs.writeFileSync(file, content, 'utf-8');

// Update game.js WhatsApp share text to point to /doe/ instead of homepage
let gameFile = 'game.js';
let gameContent = fs.readFileSync(gameFile, 'utf-8');
gameContent = gameContent.replace('const DONATION_URL = "http://www.obrasocialcristorei.org.br";', 'const DONATION_URL = "https://obrasocialcristorei.org.br/doe/";');
fs.writeFileSync(gameFile, gameContent, 'utf-8');
