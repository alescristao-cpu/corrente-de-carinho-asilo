const fs = require('fs');
let file = 'index.html';
let content = fs.readFileSync(file, 'utf-8');

const newModeCard = `
            <div class="mode-card" id="startJumpMode">
              <div class="mode-icon">🏃</div>
              <h3>Jornada da Vida</h3>
              <p>Pule os obstáculos, cresça e se torne um cidadão de bem.</p>
              <button class="play-btn" style="background: linear-gradient(135deg, #4A88B7 0%, #244C6A 100%);">Jogar Jornada ▶</button>
            </div>
          </div>`;

content = content.replace('</div>\n\n          <div class="quick-donation-box">', newModeCard + '\n\n          <div class="quick-donation-box">');
if(content.indexOf('Jornada da Vida') === -1) {
    // try different spacing
    content = content.replace('</div>\r\n\r\n          <div class="quick-donation-box">', newModeCard + '\r\n\r\n          <div class="quick-donation-box">');
}

const newGameScreen = `
      <!-- Tela do Jogo: Jornada da Vida -->
      <section id="jumpGameScreen" class="screen">
        <div class="hud">
          <div class="hud-item">
            <span class="hud-label">Pontos</span>
            <span id="jumpScore" class="hud-value">0</span>
          </div>
          <div class="hud-item">
            <span class="hud-label">Fase da Vida</span>
            <span id="jumpPhase" class="hud-value" style="font-size: 24px;">👶</span>
          </div>
        </div>

        <div class="canvas-wrapper">
          <canvas id="jumpCanvas" width="800" height="300" style="background: linear-gradient(180deg, #87CEEB 0%, #E0F6FF 100%); border: 3px solid #B0E2FF; border-radius: var(--radius-md); max-width: 100%; touch-action: none;"></canvas>
          <div id="jumpInstructions" class="touch-instructions">
            👆 Pressione <strong>ESPAÇO</strong> ou <strong>TOQUE NA TELA</strong> para pular
          </div>
        </div>

        <div class="game-controls">
          <button id="backToMenuBtn3" class="btn-secondary">🏠 Menu Principal</button>
          <a href="https://obrasocialcristorei.org.br/doe/" target="_blank" class="btn-donate-inline">
            💖 Doar Agora
          </a>
        </div>
      </section>
    </main>`;

content = content.replace('</main>', newGameScreen);

fs.writeFileSync(file, content, 'utf-8');
console.log('HTML done');
