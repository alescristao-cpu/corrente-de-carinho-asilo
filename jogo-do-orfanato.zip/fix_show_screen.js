const fs = require('fs');
let c = fs.readFileSync('game.js', 'utf-8');
c = c.replace(/showScreen\('jumpGameScreen'\)/g, "showScreen('jumpGame')");
c = c.replace(/showScreen\('balloonGameScreen'\)/g, "showScreen('balloonGame')");
fs.writeFileSync('game.js', c, 'utf-8');
