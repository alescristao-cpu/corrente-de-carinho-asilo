const fs = require('fs');
let f = 'style.css';
let c = fs.readFileSync(f, 'utf-8');
if (!c.includes('.logo-icon-img')) {
    c += '\n.logo-icon-img { height: 40px; width: auto; border-radius: var(--radius-sm); background: white; padding: 4px; }\n';
    fs.writeFileSync(f, c, 'utf-8');
}

f = 'index.html';
c = fs.readFileSync(f, 'utf-8');
c = c.replace('<div class="logo-icon">💖</div>', '<img src="images/logo.png" class="logo-icon-img" alt="Logo">');
fs.writeFileSync(f, c, 'utf-8');
