const fs = require('fs');
let file = 'game.js';
let c = fs.readFileSync(file, 'utf-8');

const oldSectionRegex = /\/\/ --- EVENT LISTENERS GERAIS ---[\s\S]*?if\s*\(buttons\.soundToggle\)/;

const newSection = `// --- EVENT LISTENERS GERAIS ---
  if (buttons.startCatch) {
    buttons.startCatch.addEventListener('click', () => {
      showScreen('catchGame');
      catchGame.start();
    });
  }

  if (buttons.startMemory) {
    buttons.startMemory.addEventListener('click', () => {
      showScreen('memoryGame');
      memoryGame.start();
    });
  }

  if (buttons.startJump) {
    buttons.startJump.addEventListener('click', () => {
      showScreen('jumpGame');
      jumpGame.start();
    });
  }

  if (buttons.startBalloon) {
    buttons.startBalloon.addEventListener('click', () => {
      showScreen('balloonGame');
      balloonGame.start();
    });
  }

  if (buttons.backToMenu3) {
    buttons.backToMenu3.addEventListener('click', () => {
      jumpGame.running = false;
      showScreen('menu');
    });
  }

  if (buttons.backToMenu4) {
    buttons.backToMenu4.addEventListener('click', () => {
      balloonGame.running = false;
      clearInterval(balloonGame.timerInterval);
      showScreen('menu');
    });
  }

  if (buttons.soundToggle)`;

c = c.replace(oldSectionRegex, newSection);

fs.writeFileSync(file, c, 'utf-8');
