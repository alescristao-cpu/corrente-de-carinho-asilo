const fs = require('fs');
let file = 'game.js';
let content = fs.readFileSync(file, 'utf-8');

// 1. Add jumpGameScreen to screens and buttons
content = content.replace("memoryGame: document.getElementById('memoryGameScreen')", "memoryGame: document.getElementById('memoryGameScreen'),\n    jumpGame: document.getElementById('jumpGameScreen')");
content = content.replace("startMemory: document.getElementById('startMemoryMode'),", "startMemory: document.getElementById('startMemoryMode'),\n    startJump: document.getElementById('startJumpMode'),");
content = content.replace("backToMenu2: document.getElementById('backToMenuBtn2'),", "backToMenu2: document.getElementById('backToMenuBtn2'),\n    backToMenu3: document.getElementById('backToMenuBtn3'),");

// 2. The JumpGame class
const jumpGameLogic = `

  // --- MODO 3: JORNADA DA VIDA (ENDLESS RUNNER) ---
  class JumpGame {
    constructor() {
      this.canvas = document.getElementById('jumpCanvas');
      if(!this.canvas) return;
      this.ctx = this.canvas.getContext('2d');
      this.scoreEl = document.getElementById('jumpScore');
      this.phaseEl = document.getElementById('jumpPhase');
      
      this.running = false;
      this.score = 0;
      this.speed = 5;
      
      this.player = {
        x: 50,
        y: 200,
        width: 40,
        height: 40,
        vy: 0,
        gravity: 0.8,
        jumpStrength: -14,
        isGrounded: false,
        emoji: '👶'
      };
      
      this.obstacles = [];
      this.spawnTimer = 0;
      this.nextSpawn = 100;
      
      this.bindEvents();
    }
    
    bindEvents() {
      const jump = (e) => {
        if(e) e.preventDefault();
        if(!this.running) return;
        if(this.player.isGrounded) {
          this.player.vy = this.player.jumpStrength;
          this.player.isGrounded = false;
          sound.playCardFlip();
        }
      };
      
      window.addEventListener('keydown', (e) => {
        if(e.code === 'Space' || e.code === 'ArrowUp') jump(e);
      });
      
      if(this.canvas) {
        this.canvas.addEventListener('touchstart', jump, {passive: false});
        this.canvas.addEventListener('mousedown', jump);
      }
    }
    
    start() {
      this.running = true;
      this.score = 0;
      this.speed = 5;
      this.obstacles = [];
      this.spawnTimer = 0;
      this.nextSpawn = 100;
      this.player.y = this.canvas.height - 50 - this.player.height;
      this.player.vy = 0;
      this.player.isGrounded = true;
      this.player.emoji = '👶';
      this.updateHUD();
      
      this.lastTime = performance.now();
      requestAnimationFrame((t) => this.loop(t));
    }
    
    spawnObstacle() {
      const types = ['🚧', '🪨', '🛑'];
      const type = types[Math.floor(Math.random() * types.length)];
      this.obstacles.push({
        x: this.canvas.width,
        y: this.canvas.height - 50 - 30, // 50 ground height, 30 obs height
        width: 30,
        height: 30,
        emoji: type
      });
    }
    
    update() {
      // Player physics
      this.player.vy += this.player.gravity;
      this.player.y += this.player.vy;
      
      const groundY = this.canvas.height - 50;
      if (this.player.y + this.player.height >= groundY) {
        this.player.y = groundY - this.player.height;
        this.player.vy = 0;
        this.player.isGrounded = true;
      }
      
      // Update obstacles
      for (let i = this.obstacles.length - 1; i >= 0; i--) {
        let obs = this.obstacles[i];
        obs.x -= this.speed;
        
        // Collision detection
        if (
          this.player.x < obs.x + obs.width - 5 &&
          this.player.x + this.player.width - 5 > obs.x &&
          this.player.y < obs.y + obs.height - 5 &&
          this.player.y + this.player.height - 5 > obs.y
        ) {
          // Hit!
          this.running = false;
          sound.playHurt();
          setTimeout(() => {
             openResultModal(Math.floor(this.score), "Jornada da Vida", "Cada obstáculo superado representa um passo na jornada de nossas crianças. Sua doação ajuda a pavimentar esse caminho!");
          }, 300);
          return;
        }
        
        if (obs.x + obs.width < 0) {
          this.obstacles.splice(i, 1);
        }
      }
      
      // Spawning
      this.spawnTimer++;
      if (this.spawnTimer >= this.nextSpawn) {
        this.spawnObstacle();
        this.spawnTimer = 0;
        this.nextSpawn = Math.max(50, 100 - this.speed * 2) + Math.random() * 50;
      }
      
      // Score and Speed
      this.score += 0.1;
      this.speed = 5 + (this.score / 200);
      
      // Growth Phase
      let newEmoji = '👶';
      if (this.score > 1000) newEmoji = '👨‍🎓';
      else if (this.score > 600) newEmoji = '🧑';
      else if (this.score > 300) newEmoji = '👦';
      
      if(newEmoji !== this.player.emoji) {
         this.player.emoji = newEmoji;
         sound.playVictory();
         // increase size slightly to represent growth
         this.player.width = 40 + (this.score > 300 ? 5 : 0) + (this.score > 600 ? 5 : 0);
         this.player.height = this.player.width;
      }
      
      this.updateHUD();
    }
    
    draw() {
      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
      
      // Draw Ground
      this.ctx.fillStyle = '#A3E4D7';
      this.ctx.fillRect(0, this.canvas.height - 50, this.canvas.width, 50);
      
      // Draw Player
      this.ctx.font = \`\${this.player.height}px Arial\`;
      this.ctx.textAlign = 'center';
      this.ctx.textBaseline = 'bottom';
      this.ctx.fillText(this.player.emoji, this.player.x + this.player.width/2, this.player.y + this.player.height);
      
      // Draw Obstacles
      this.ctx.font = '30px Arial';
      this.obstacles.forEach(obs => {
        this.ctx.fillText(obs.emoji, obs.x + obs.width/2, obs.y + obs.height);
      });
    }
    
    updateHUD() {
      this.scoreEl.textContent = Math.floor(this.score);
      this.phaseEl.textContent = this.player.emoji;
    }
    
    loop(timestamp) {
      if (!this.running) return;
      this.update();
      this.draw();
      requestAnimationFrame((t) => this.loop(t));
    }
  }
`;

content = content.replace('// --- INICIALIZAÇÃO ---', jumpGameLogic + '\n  // --- INICIALIZAÇÃO ---');

// 3. Initialize JumpGame
content = content.replace('const catchGame = new CatchGame();', 'const catchGame = new CatchGame();\n  const jumpGame = new JumpGame();');

// 4. Bind Menu Buttons
const newBinds = `
  if(buttons.startJump) {
    buttons.startJump.addEventListener('click', () => {
      showScreen('jumpGameScreen');
      jumpGame.start();
    });
  }
  if(buttons.backToMenu3) {
    buttons.backToMenu3.addEventListener('click', () => {
      jumpGame.running = false;
      showScreen('menuScreen');
    });
  }
`;
content = content.replace("buttons.startMemory.addEventListener('click', () => {", newBinds + "\n  buttons.startMemory.addEventListener('click', () => {");

fs.writeFileSync(file, content, 'utf-8');
console.log('JS done');
