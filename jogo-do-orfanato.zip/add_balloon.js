const fs = require('fs');

// --- HTML UPDATE ---
let file = 'index.html';
let content = fs.readFileSync(file, 'utf-8');

const newModeCard = `
            <div class="mode-card" id="startBalloonMode">
              <div class="mode-icon">🎈</div>
              <h3>Balões dos Sonhos</h3>
              <p>Estoure os balões que sobem e ajude a realizar os sonhos das nossas crianças.</p>
              <button class="play-btn" style="background: linear-gradient(135deg, #FF9A9E 0%, #FECFEF 100%); color: #122B40;">Jogar Balões ▶</button>
            </div>
          </div>`;

content = content.replace('</div>\r\n\r\n          <div class="quick-donation-box">', newModeCard + '\r\n\r\n          <div class="quick-donation-box">');
content = content.replace('</div>\n\n          <div class="quick-donation-box">', newModeCard + '\n\n          <div class="quick-donation-box">');

const newGameScreen = `
      <!-- Tela do Jogo: Balões dos Sonhos -->
      <section id="balloonGameScreen" class="screen">
        <div class="hud">
          <div class="hud-item">
            <span class="hud-label">Sonhos Realizados</span>
            <span id="balloonScore" class="hud-value">0</span>
          </div>
          <div class="hud-item">
            <span class="hud-label">Tempo</span>
            <span id="balloonTime" class="hud-value" style="color: #E74C3C;">30s</span>
          </div>
        </div>

        <div class="canvas-wrapper">
          <canvas id="balloonCanvas" width="600" height="700" style="background: linear-gradient(180deg, #A1C4FD 0%, #C2E9FB 100%); border: 3px solid #8FD3F4; border-radius: var(--radius-md); max-width: 100%; touch-action: none;"></canvas>
          <div class="touch-instructions">
            👆 <strong>TOQUE</strong> nos balões antes que eles voem embora!
          </div>
        </div>

        <div class="game-controls">
          <button id="backToMenuBtn4" class="btn-secondary">🏠 Menu Principal</button>
          <a href="https://obrasocialcristorei.org.br/doe/" target="_blank" class="btn-donate-inline">
            💖 Apoiar Sonhos
          </a>
        </div>
      </section>
    </main>`;

content = content.replace('</main>', newGameScreen);
fs.writeFileSync(file, content, 'utf-8');

// --- CSS UPDATE ---
file = 'style.css';
content = fs.readFileSync(file, 'utf-8');
content = content.replace('grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));', 'grid-template-columns: 1fr 1fr;');
if (!content.includes('grid-template-columns: 1fr 1fr;')) {
    content = content.replace('grid-template-columns: 1fr 1fr;', 'grid-template-columns: 1fr 1fr;'); // just in case
}
fs.writeFileSync(file, content, 'utf-8');

// --- JS UPDATE ---
file = 'game.js';
content = fs.readFileSync(file, 'utf-8');

// Add DOM references
content = content.replace("jumpGame: document.getElementById('jumpGameScreen')", "jumpGame: document.getElementById('jumpGameScreen'),\n    balloonGame: document.getElementById('balloonGameScreen')");
content = content.replace("startJump: document.getElementById('startJumpMode'),", "startJump: document.getElementById('startJumpMode'),\n    startBalloon: document.getElementById('startBalloonMode'),");
content = content.replace("backToMenu3: document.getElementById('backToMenuBtn3'),", "backToMenu3: document.getElementById('backToMenuBtn3'),\n    backToMenu4: document.getElementById('backToMenuBtn4'),");

// Add BalloonGame class
const balloonGameLogic = `

  // --- MODO 4: BALÕES DOS SONHOS (TAPPER) ---
  class BalloonGame {
    constructor() {
      this.canvas = document.getElementById('balloonCanvas');
      if(!this.canvas) return;
      this.ctx = this.canvas.getContext('2d');
      this.scoreEl = document.getElementById('balloonScore');
      this.timeEl = document.getElementById('balloonTime');
      
      this.running = false;
      this.score = 0;
      this.timeLeft = 30;
      
      this.balloons = [];
      this.particles = [];
      this.spawnTimer = 0;
      this.nextSpawn = 60;
      
      this.emojis = ['🎈', '🌟', '🧸', '🎨', '⚽'];
      
      this.bindEvents();
    }
    
    bindEvents() {
      const handleTap = (e) => {
        if(!this.running) return;
        e.preventDefault();
        
        let clientX, clientY;
        if(e.touches && e.touches.length > 0) {
          clientX = e.touches[0].clientX;
          clientY = e.touches[0].clientY;
        } else {
          clientX = e.clientX;
          clientY = e.clientY;
        }
        
        const rect = this.canvas.getBoundingClientRect();
        const scaleX = this.canvas.width / rect.width;
        const scaleY = this.canvas.height / rect.height;
        const x = (clientX - rect.left) * scaleX;
        const y = (clientY - rect.top) * scaleY;
        
        // Check hits (reverse order to hit top balloons first)
        for(let i = this.balloons.length - 1; i >= 0; i--) {
          const b = this.balloons[i];
          const dist = Math.hypot(b.x - x, b.y - y);
          if(dist <= b.radius * 1.5) {
             // Pop!
             this.score += 10;
             sound.playCoin();
             this.createParticles(b.x, b.y);
             this.balloons.splice(i, 1);
             this.updateHUD();
             break; // only pop one per tap
          }
        }
      };
      
      if(this.canvas) {
        this.canvas.addEventListener('touchstart', handleTap, {passive: false});
        this.canvas.addEventListener('mousedown', handleTap);
      }
    }
    
    start() {
      this.running = true;
      this.score = 0;
      this.timeLeft = 30;
      this.balloons = [];
      this.particles = [];
      this.updateHUD();
      
      this.lastTime = performance.now();
      
      // Timer interval
      this.timerInterval = setInterval(() => {
        this.timeLeft--;
        this.updateHUD();
        if(this.timeLeft <= 0) {
           this.endGame();
        }
      }, 1000);
      
      requestAnimationFrame((t) => this.loop(t));
    }
    
    endGame() {
       this.running = false;
       clearInterval(this.timerInterval);
       setTimeout(() => {
          openResultModal(this.score, "Balões dos Sonhos", "Você realizou " + (this.score/10) + " sonhos! A Obra Social Cristo Rei trabalha diariamente para que os sonhos dessas crianças decolem. Junte-se a nós!");
       }, 500);
    }
    
    spawnBalloon() {
      const type = this.emojis[Math.floor(Math.random() * this.emojis.length)];
      const radius = 30 + Math.random() * 15;
      const x = radius + Math.random() * (this.canvas.width - radius * 2);
      this.balloons.push({
        x: x,
        y: this.canvas.height + radius,
        radius: radius,
        speed: 2 + Math.random() * 3,
        wobble: Math.random() * Math.PI * 2,
        wobbleSpeed: 0.02 + Math.random() * 0.05,
        emoji: type
      });
    }
    
    createParticles(x, y) {
      for(let i=0; i<6; i++) {
         this.particles.push({
            x: x,
            y: y,
            vx: (Math.random() - 0.5) * 10,
            vy: (Math.random() - 0.5) * 10,
            life: 1.0
         });
      }
    }
    
    update() {
      // Spawning
      this.spawnTimer++;
      if(this.spawnTimer >= this.nextSpawn) {
        this.spawnBalloon();
        this.spawnTimer = 0;
        this.nextSpawn = Math.max(15, 40 - (30 - this.timeLeft)); // gets faster
      }
      
      // Update balloons
      for(let i = this.balloons.length - 1; i >= 0; i--) {
         let b = this.balloons[i];
         b.y -= b.speed;
         b.wobble += b.wobbleSpeed;
         b.x += Math.sin(b.wobble) * 1.5;
         
         if(b.y < -b.radius) {
            this.balloons.splice(i, 1);
         }
      }
      
      // Update particles
      for(let i = this.particles.length - 1; i >= 0; i--) {
         let p = this.particles[i];
         p.x += p.vx;
         p.y += p.vy;
         p.life -= 0.05;
         if(p.life <= 0) this.particles.splice(i, 1);
      }
    }
    
    draw() {
      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
      
      // Draw balloons
      this.ctx.textAlign = 'center';
      this.ctx.textBaseline = 'middle';
      this.balloons.forEach(b => {
         // string / thread
         this.ctx.beginPath();
         this.ctx.moveTo(b.x, b.y + b.radius * 0.8);
         this.ctx.lineTo(b.x + Math.sin(b.wobble)*5, b.y + b.radius * 2.5);
         this.ctx.strokeStyle = 'rgba(255,255,255,0.7)';
         this.ctx.lineWidth = 2;
         this.ctx.stroke();
         
         this.ctx.font = Math.floor(b.radius * 1.8) + 'px Arial';
         this.ctx.fillText(b.emoji, b.x, b.y);
      });
      
      // Draw particles (stars)
      this.ctx.fillStyle = '#FFC107';
      this.particles.forEach(p => {
         this.ctx.globalAlpha = Math.max(0, p.life);
         this.ctx.beginPath();
         this.ctx.arc(p.x, p.y, 4, 0, Math.PI*2);
         this.ctx.fill();
      });
      this.ctx.globalAlpha = 1.0;
    }
    
    updateHUD() {
      this.scoreEl.textContent = this.score;
      this.timeEl.textContent = this.timeLeft + 's';
    }
    
    loop(timestamp) {
      if (!this.running) return;
      this.update();
      this.draw();
      requestAnimationFrame((t) => this.loop(t));
    }
  }
`;

content = content.replace('// --- INICIALIZAÇÃO ---', balloonGameLogic + '\n  // --- INICIALIZAÇÃO ---');
content = content.replace('const jumpGame = new JumpGame();', 'const jumpGame = new JumpGame();\n  const balloonGame = new BalloonGame();');

const newBinds = `
  if(buttons.startBalloon) {
    buttons.startBalloon.addEventListener('click', () => {
      showScreen('balloonGameScreen');
      balloonGame.start();
    });
  }
  if(buttons.backToMenu4) {
    buttons.backToMenu4.addEventListener('click', () => {
      balloonGame.running = false;
      clearInterval(balloonGame.timerInterval);
      showScreen('menuScreen');
    });
  }
`;
content = content.replace("buttons.startMemory.addEventListener('click', () => {", newBinds + "\n  buttons.startMemory.addEventListener('click', () => {");

fs.writeFileSync(file, content, 'utf-8');
console.log('Balloon Game successfully injected!');
