const fs = require('fs');
let file = 'game.js';
let content = fs.readFileSync(file, 'utf-8');

const oldBlockRegex = /this\.cardData = \[[^\]]+\];/;
const newBlock = `this.cardData = [
        { img: 'images/img1.jpg', emoji: '🎁', name: 'Alegria e Presentes' },
        { img: 'images/img2.jpg', emoji: '🍲', name: 'Refeição com Amor' },
        { img: 'images/img3.jpg', emoji: '🧩', name: 'Jogos e Aprendizado' },
        { img: 'images/img4.jpg', emoji: '📚', name: 'Cantinho da Leitura' },
        { img: 'images/img5.jpg', emoji: '🥰', name: 'Sorrisos e Carinho' },
        { img: 'images/logo.png', emoji: '💙', name: 'Cristo Rei' },
        { img: 'images/img6.jpg', emoji: '📸', name: 'História e Memória' },
        { img: 'images/img7.jpg', emoji: '🏗️', name: 'Oficina Criativa' }
      ];`;

content = content.replace(oldBlockRegex, newBlock);
fs.writeFileSync(file, content, 'utf-8');
